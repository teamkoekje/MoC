package moc.challenge;

import annotations.Editable;

@Editable
public class ChallengeImpl implements ChallengeExample {

    @Override
    public void functionName(int parameter) {
        // TODO: Implement
    }

}
